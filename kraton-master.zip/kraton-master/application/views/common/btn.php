<button type="reset" class="btn btn-default"> <span class="fa fa-times"></span> Reset</button>
<button type="submit" class="btn btn-primary"> <span class="fa fa-save"></span> Save</button>
